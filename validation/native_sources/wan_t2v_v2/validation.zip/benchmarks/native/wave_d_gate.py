"""Native video evidence gate. Missing Wan/MiniMax coverage remains NOT_MET."""

import hashlib
import json
from pathlib import Path

from benchmarks.native.video_semantic import semantic
from benchmarks.native.wave_a import digest
from benchmarks.native.wave_a_gate import evaluate

ROOT = Path(__file__).resolve().parents[2]


def main():
    inputs = {}

    def verify_report(kind, setup, observed, verified_raw):
        runtime = json.loads((ROOT / "deployments/kaggle/runtime_wave_d.json").read_text())
        is_comfy = kind.startswith("minimax")
        pin = runtime["comfyui" if is_comfy else "diffusers"]
        assert setup["runtime_pins"]["comfyui" if is_comfy else "diffusers"] == pin
        versions = observed["runtime_versions"]
        names = ["torch", "torchvision", "torchaudio", "transformers"]
        if is_comfy:
            names += ["gguf", "comfy-aimdo", "comfy-kitchen"]
        else:
            assert (
                setup.get("backend_wheel_verified") is True
                and versions["diffusers"] == pin["version"]
            )
            names += ["accelerate", "imageio", "imageio-ffmpeg"]
        assert all(versions[name] == pin[name] for name in names)
        run = json.loads((ROOT / f"validation/native_{kind}_run.json").read_text())
        folder = ROOT / f"validation/native_{kind}_v{run['response']['versionNumber']}"
        packages = {
            k.lower().replace("_", "-"): v
            for k, v in json.loads(verified_raw(folder / "runtime_packages.json")).items()
        }
        assert all(packages[k] == v for k, v in versions.items())
        if not is_comfy:
            for model in observed["models"]:
                backend = model.get("runtime_after_inference")
                if not backend:
                    continue
                identity = backend["sdk_runtime"]
                assert (
                    identity["precision"] == "fp16"
                    and identity["cpu_offload"] is True
                    and identity["cuda_device"] == "cuda:0"
                )
                assert set(identity["components"]) == {"transformer", "text_encoder", "vae"}
                assert all(
                    v["dtypes"] == ["torch.float16"]
                    and v["shared_between_wrappers"] is True
                    and v["parameter_count"] > 1_000_000
                    for v in identity["components"].values()
                ), "Wan components violated exact shared FP16 load contract"
        if is_comfy:
            from model_registry.deployment import ModelCatalog

            from factory.adapters.minimax.native_nodes import SOURCE_FILES, SOURCE_REVISION

            for model in observed["models"]:
                backend = model.get("runtime_after_inference")
                if not backend:
                    continue
                assert backend["source_revision"] == SOURCE_REVISION == pin[
                    "source_revision"
                ] and backend["devices"] == [0]
                files = backend["adapter_assets"]
                for name, sha in files.items():
                    assert (
                        hashlib.sha256(
                            verified_raw(folder / model["model"] / "adapter_assets" / name)
                        ).hexdigest()
                        == sha
                    )
                for name, sha in SOURCE_FILES.items():
                    key = next(
                        k for k in files if k.endswith("/minimax_upstream_" + Path(name).name)
                    )
                    assert files[key] == sha
                key = next(k for k in files if k.endswith("/factory_minimax_loader/__init__.py"))
                assert (
                    files[key]
                    == hashlib.sha256(
                        (ROOT / "factory/adapters/minimax/loader_node.py").read_bytes()
                    ).hexdigest()
                )
                marker = "FACTORY_MINIMAX_RUNTIME "
                attestations = [
                    json.loads(line.split(marker, 1)[1])
                    for line in verified_raw(folder / model["model"] / "backend.log")
                    .decode(errors="replace")
                    .splitlines()
                    if marker in line
                ]
                assert attestations and model.get("precision_attestations") == attestations, (
                    "Missing exact MiniMax FP16 runtime attestation; diagnostic attempt is not V3"
                )
                selected = ModelCatalog(ROOT / "manifests").get(model["model"])
                assert selected.weights.default_precision == "fp16"
                checkpoint = Path(
                    selected.weights.files["primary"].destination
                    or selected.weights.files["primary"].path
                ).name
                assert all(
                    a["precision"] == "fp16"
                    and a["compute_dtype"] == "torch.float16"
                    and a["manual_cast_dtype"] in {"None", "torch.float16"}
                    and a["load_device"] == "cuda:0"
                    and a["offload_device"] == "cpu"
                    and a["checkpoint"] == checkpoint
                    for a in attestations
                )
        for name, spec in observed["input_assets"].items():
            raw = verified_raw(folder / "inputs" / name / "source.bin")
            assert (
                len(raw) == spec["size_bytes"] and hashlib.sha256(raw).hexdigest() == spec["sha256"]
            )
            inputs[name] = raw
        verifier = observed.get("semantic_verifiers")
        if verifier:
            pins = json.loads((ROOT / "benchmarks/native/image_semantic_pins.json").read_text())
            assert verifier["pins_sha256"] == digest(pins) and verifier["scope"] == pins["scope"]
            assert verifier["verified_files"] == {
                name: {**spec, "matched": True} for name, spec in pins["files"].items()
            }
            assert verifier["loaded"] == {
                "parameter_count": 151277313,
                "devices": ["cpu"],
                "dtypes": ["torch.float32"],
            }

    result = evaluate(
        wave="d",
        models=("wan-2.2", "minimax-h3", "minimax-h3-turbo", "minimax-h3-reference"),
        kinds=("wan_t2v", "wan_conditioned", "minimax_t2v"),
        validator=lambda case, output: semantic(case, output, assets=inputs),
        report_validator=verify_report,
    )
    previous = json.loads((ROOT / "validation/native_wave_c_gate.json").read_text())
    if previous["exit_gate"] != "PASS":
        result["exit_gate"] = "NOT_MET"
        result["findings"].append("Wave C dependency gate is not PASS")
    (ROOT / "validation/native_wave_d_gate.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "exit_gate": result["exit_gate"],
                "native_pass": sum(c["status"] == "PASS" for c in result["cases"]),
                "findings": result["findings"],
            }
        )
    )
    return 0 if result["exit_gate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
