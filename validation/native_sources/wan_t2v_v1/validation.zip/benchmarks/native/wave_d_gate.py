"""Native video evidence gate. Missing Wan/MiniMax coverage remains NOT_MET."""

import json
from pathlib import Path

from benchmarks.native.video_semantic import semantic
from benchmarks.native.wave_a import digest
from benchmarks.native.wave_a_gate import evaluate

ROOT = Path(__file__).resolve().parents[2]


def main():
    def verify_report(kind, setup, observed, verified_raw):
        pin = json.loads((ROOT / "deployments/kaggle/runtime_wave_d.json").read_text())["diffusers"]
        assert (
            setup["runtime_pins"]["diffusers"] == pin
            and setup.get("backend_wheel_verified") is True
        )
        versions = observed["runtime_versions"]
        assert versions["diffusers"] == pin["version"]
        assert all(
            versions[k] == pin[k]
            for k in [
                "torch",
                "torchvision",
                "torchaudio",
                "transformers",
                "accelerate",
                "imageio",
                "imageio-ffmpeg",
            ]
        )
        run = json.loads((ROOT / f"validation/native_{kind}_run.json").read_text())
        folder = ROOT / f"validation/native_{kind}_v{run['response']['versionNumber']}"
        packages = {
            k.lower().replace("_", "-"): v
            for k, v in json.loads(verified_raw(folder / "runtime_packages.json")).items()
        }
        assert all(packages[k] == v for k, v in versions.items())
        verifier = observed.get("semantic_verifiers")
        if verifier:
            pins = json.loads((ROOT / "benchmarks/native/image_semantic_pins.json").read_text())
            assert verifier["pins_sha256"] == digest(pins) and verifier["scope"] == pins["scope"]
            assert verifier["verified_files"] == {
                name: {**spec, "matched": True} for name, spec in pins["files"].items()
            }
            assert verifier["loaded"] == {
                "parameter_count": 151277313,
                "devices": ["cpu"],
                "dtypes": ["torch.float32"],
            }

    result = evaluate(
        wave="d",
        models=("wan-2.2", "minimax-h3", "minimax-h3-turbo", "minimax-h3-reference"),
        kinds=("wan_t2v",),
        validator=semantic,
        report_validator=verify_report,
    )
    previous = json.loads((ROOT / "validation/native_wave_c_gate.json").read_text())
    if previous["exit_gate"] != "PASS":
        result["exit_gate"] = "NOT_MET"
        result["findings"].append("Wave C dependency gate is not PASS")
    (ROOT / "validation/native_wave_d_gate.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "exit_gate": result["exit_gate"],
                "native_pass": sum(c["status"] == "PASS" for c in result["cases"]),
                "findings": result["findings"],
            }
        )
    )
    return 0 if result["exit_gate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
