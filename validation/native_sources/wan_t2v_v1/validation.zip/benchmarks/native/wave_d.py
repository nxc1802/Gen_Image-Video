"""Exact native video validation; initial Wan baseline, never public READY."""

import argparse
import asyncio
import base64
import hashlib
import json
import traceback
from importlib.metadata import version
from pathlib import Path

from model_registry.deployment_validator import inspect_environment

from benchmarks.native.video_semantic import VideoVerifier, semantic
from benchmarks.native.wave_a import digest, encoded, model_run
from factory.core.media import MediaRequest

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument("--cases", nargs="+", required=True)
    args = parser.parse_args()
    suite = json.loads((ROOT / "benchmarks/native/golden_wave_d.json").read_text())
    cases = [c for c in suite["cases"] if c["id"] in args.cases and c["model"] in args.models]
    if set(args.cases) != {c["id"] for c in cases} or set(args.models) != {
        c["model"] for c in cases
    }:
        raise ValueError("Exact selected video cases/models required")
    if any(c["assets"] for c in cases):
        raise ValueError(
            "This initial video runner supports text-only baseline; no asset substitution"
        )

    async def execute(context, adapter, case):
        request = MediaRequest(
            model=case["model"], capability=case["capability"], inputs=case["request"]
        )
        capability = adapter.resolve_capability(request, case["capability"])
        required = adapter.required_capabilities(request, capability) | {capability}
        if any(
            not context.model.capabilities.get(c) or c not in adapter.capabilities for c in required
        ):
            raise ValueError("Undeclared video capability")
        adapter.validate_request(context.model, request, capability)
        prepared = await asyncio.to_thread(adapter.prepare, context, request, capability)
        raw = await asyncio.to_thread(adapter.infer, context, prepared)
        result = await asyncio.to_thread(adapter.normalize_output, context, prepared, raw)
        for item in result["artifacts"]:
            item["data_base64"] = base64.b64encode(item.pop("data")).decode()
        result["seed"] = case["request"]["seed"]
        return result

    report = {
        "classification": "REAL_NATIVE_VALIDATION_ATTEMPT",
        "hardware": inspect_environment().gpus,
        "case_definitions": cases,
        "input_assets": {},
        "cases_sha256": digest({"cases": cases, "assets": {}}),
        "runtime_versions": {
            n: version(n)
            for n in [
                "diffusers",
                "torch",
                "torchvision",
                "torchaudio",
                "transformers",
                "accelerate",
                "huggingface-hub",
                "psutil",
                "imageio",
                "imageio-ffmpeg",
            ]
        },
        "models": [],
        "status": "NOT_MET",
        "fallback": False,
        "production_ready": False,
        "full_factory_e2e_executed": False,
    }
    assert set(report["hardware"]) == {0, 1} and all(
        "t4" in v["name"].lower() for v in report["hardware"].values()
    ), "Exact Dual-T4 required"
    for model in args.models:
        directory = args.output / model
        directory.mkdir(parents=True, exist_ok=True)
        result = asyncio.run(
            model_run(
                model,
                args.root,
                directory,
                [c for c in cases if c["model"] == model],
                executor=execute,
                validator=semantic,
            )
        )
        report["models"].append(result)
    if any(c["runs"] for m in report["models"] for c in m["cases"]):
        try:
            verifier = VideoVerifier(args.root / "semantic_weights/clip", {})
            report["semantic_verifiers"] = verifier.evidence
            for model in report["models"]:
                directory = args.output / model["model"]
                for native in model["cases"]:
                    case = next(c for c in cases if c["id"] == native["case_id"])
                    for run in native["runs"]:
                        path = directory / run["output_file"]
                        output = json.loads(path.read_text())
                        output["verification"] = verifier.evaluate_video(
                            base64.b64decode(output["artifacts"][0]["data_base64"], validate=True),
                            case["expected"],
                        )
                        path.write_bytes(encoded(output))
                        run["output_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
                        run["semantic_validation"] = semantic(case, output)
                    native["status"] = (
                        "PASS"
                        if len(native["runs"]) == 4
                        and all(
                            r["semantic_validation"]["status"] == "PASS" for r in native["runs"]
                        )
                        else "NOT_MET"
                    )
                model["status"] = (
                    "PASS"
                    if model.get("stop_verified")
                    and all(c["status"] == "PASS" for c in model["cases"])
                    else "NOT_MET"
                )
                (directory / "observation.json").write_text(json.dumps(model, indent=2) + "\n")
        except Exception as exc:
            report["semantic_verifier_error"] = {
                "type": type(exc).__name__,
                "message": str(exc),
                "traceback": traceback.format_exc(),
            }
    report["status"] = (
        "PASS"
        if report.get("semantic_verifiers")
        and not report.get("semantic_verifier_error")
        and all(m["status"] == "PASS" for m in report["models"])
        else "NOT_MET"
    )
    (args.output / "wave_d.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {"status": report["status"], "scope": "INITIAL_WAN_BASELINE_ONLY_NOT_FULL_WAVE_D"}
        )
    )
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
