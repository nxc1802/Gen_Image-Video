"""
factory_contracts/jobs/job_contract.py
Factory Job Lifecycle, Leases, and Progress Contract
"""
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from factory_contracts.errors.error_contract import ErrorDetail
from factory_contracts.tasks import normalize_model, normalize_task


class JobState(str, Enum):
    CREATED = "CREATED"
    QUEUED = "QUEUED"
    ADMITTED = "ADMITTED"
    RUNNING = "RUNNING"
    STREAMING = "STREAMING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    RETRYING = "RETRYING"


class JobProgress(BaseModel):
    model_config = ConfigDict(extra="forbid")

    stage: str = Field(default="queued", description="Lifecycle stage: queued, loading, sampling, encoding, completed")
    step: int = Field(default=0, ge=0)
    total: int = Field(default=0, ge=0)
    percent: float = Field(default=0.0, ge=0.0, le=100.0)
    message: Optional[str] = None
    preview_url: Optional[str] = None


class WorkerLease(BaseModel):
    model_config = ConfigDict(extra="forbid")

    worker_id: str = Field(..., description="Unique worker daemon identifier")
    gpu_device: Optional[int] = Field(default=None, description="Assigned GPU device index")
    lease_token: str = Field(default="", description="Cryptographic lease token held by worker")
    leased_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    lease_expires_at: Optional[datetime] = Field(default=None, description="Lease expiration threshold (300s TTL)")


class ArtifactReference(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    artifact_id: str = Field(..., description="Unique artifact identifier, e.g. art-...")
    type: str = Field(default="media", description="Artifact type: media, audio, video, image")
    mime_type: str = Field(..., description="MIME type, e.g. 'image/png', 'video/mp4'")
    size_bytes: int = Field(..., ge=0)
    storage_path: str = Field(..., description="Internal S3/MinIO key")
    download_url: Optional[str] = Field(default=None, description="Presigned S3 GET URL (expiring in 24h)")
    url: Optional[str] = Field(default=None, description="Alias for download_url for E2E and client compatibility")
    sha256: str = Field(..., min_length=64, max_length=64, description="Hex-encoded SHA256 checksum")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @model_validator(mode="after")
    def sync_url_fields(self) -> "ArtifactReference":
        if not self.url and self.download_url:
            self.url = self.download_url
        elif not self.download_url and self.url:
            self.download_url = self.url
        elif not self.url and not self.download_url:
            raise ValueError("Either 'url' or 'download_url' must be provided.")
        return self


class JobTelemetry(BaseModel):
    model_config = ConfigDict(extra="allow")

    queue_wait_ms: Optional[float] = None
    inference_duration_ms: Optional[float] = None
    tokens_per_sec: Optional[float] = None
    fps: Optional[float] = None
    peak_vram_mb: Optional[float] = None


class JobSubmissionRequest(BaseModel):
    """Client request payload for POST /v1/jobs."""
    model_config = ConfigDict(extra="forbid")

    service: str = Field(..., description="Target service subsystem, e.g. 'image'")
    model: str = Field(..., description="Model family ID, e.g. 'qwen-image-2.1'")
    task: str = Field(..., description="Capability task name, e.g. 'inpaint' or 'text_to_image'")
    inputs: Dict[str, Any] = Field(..., description="Pre-validated task input dictionary")
    priority: int = Field(default=10, ge=1, le=100, description="1=low, 10=standard, 100=critical")
    idempotency_key: Optional[str] = Field(default=None, max_length=128)

    @model_validator(mode="after")
    def normalize_request_capability(self):
        self.task = normalize_task(self.task, engine=self.service, inputs=self.inputs)
        return self

    @field_validator("model", mode="before")
    @classmethod
    def _validate_model(cls, v: Any) -> str:
        if v is None:
            return ""
        return normalize_model(str(v).strip())


class FactoryJob(BaseModel):
    """Authoritative Factory Job entity tracked in PostgreSQL and Redis."""
    model_config = ConfigDict(extra="forbid")

    job_id: str = Field(..., pattern=r"^job-[0-9a-f-]+$", description="Job UUID v4")
    request_id: str = Field(..., pattern=r"^req-[0-9a-f-]+$", description="Originating request UUID v4")
    trace_id: Optional[str] = Field(default=None, description="OpenTelemetry W3C trace ID correlating distributed span tree")
    idempotency_key: Optional[str] = None
    service: str
    model: str
    task: str
    inputs: Dict[str, Any]
    priority: int = 10
    state: JobState = JobState.CREATED
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: JobProgress = Field(default_factory=JobProgress)
    worker: Optional[WorkerLease] = None
    retry_count: int = Field(default=0, ge=0)
    max_retries: int = Field(default=3, ge=0)
    error: Optional[ErrorDetail] = None
    artifacts: List[ArtifactReference] = Field(default_factory=list)
    result: Optional[Any] = Field(default=None, description="In-memory inference result payload")
    telemetry: JobTelemetry = Field(default_factory=JobTelemetry)
    deployment_session_id: Optional[str] = None
    deployment_config_sha256: Optional[str] = None
    devices: List[int] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def read_persisted_capability(cls, data):
        # Reading pre-migration persisted jobs is an ingress boundary too.
        if isinstance(data, dict) and "task" in data:
            from factory_contracts.capabilities import CAPABILITIES
            if not isinstance(data["task"], str) or data["task"] not in CAPABILITIES:
                data = {**data, "task": normalize_task(data["task"], engine=data.get("service"), inputs=data.get("inputs", {}))}
        return data


class AssetRecord(BaseModel):
    """Persistent Asset record tracked in PostgreSQL/SQLite and Storage Providers."""
    model_config = ConfigDict(extra="ignore")

    asset_id: str = Field(..., description="Unique asset identifier, e.g. ast-...")
    sha256: str = Field(..., min_length=64, max_length=64, description="Hex-encoded SHA256 checksum")
    mime_type: str = Field(..., description="MIME content type")
    size_bytes: int = Field(..., ge=0, description="Size of asset in bytes")
    storage_path: str = Field(..., description="Internal S3/storage path key")
    s3_url: str = Field(..., description="Full S3 or storage endpoint URL")
    download_url: str = Field(..., description="Public/internal download URL endpoint")
    filename: str = Field(..., description="Original uploaded filename")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    verified: bool = Field(default=True, description="Whether media validation succeeded")

