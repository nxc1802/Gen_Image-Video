"""Private, pinned Qwen Image Comfy nodes; this code generates no image output."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess

GGUF_REVISION = "6ea2651e7df66d7585f6ffee804b20e92fb38b8a"
GGUF_LOADER_SHA256 = "ffff39d209ce22654e67378b80c6a3ca3d349cf8f00ec267085bd16e194730c2"
ARCH_ANCHOR = '    type_str = get_field(reader, "general.type", str)'
ARCH_HINT = """
    # Explicit Factory Qwen Image 2.1 adapter hint for its metadata-free GGUF.
    # Native Comfy still selects the actual diffusion model from these weights.
    if arch_str is None and not is_text_model and {
        "img_in.weight", "modulation.1.weight", "txt_in.text_norm.weight",
        "transformer_blocks.0.img_mlp.gate_up.weight",
    }.issubset({name for name, _ in tensors}):
        arch_str = "qwen_image"
"""


def install(base, backend, source_dir):
    extension = source_dir / "custom_nodes/ComfyUI-GGUF"
    observed = subprocess.check_output(
        ["git", "-C", str(extension), "rev-parse", "HEAD"], text=True
    ).strip()
    if observed != GGUF_REVISION:
        raise RuntimeError(
            "Selected Qwen Image adapter requires its explicit pinned ComfyUI-GGUF checkout"
        )
    original = (extension / "loader.py").read_bytes()
    if hashlib.sha256(original).hexdigest() != GGUF_LOADER_SHA256:
        raise RuntimeError(
            "Qwen Image GGUF loader source differs from its pinned native dependency"
        )
    text = original.decode()
    if text.count(ARCH_ANCHOR) != 1:
        raise RuntimeError("Native GGUF loader has an unsupported architecture-detection layout")
    patched = text.replace(ARCH_ANCHOR, ARCH_ANCHOR + ARCH_HINT)
    compile(patched, "qwen_image_gguf_loader", "exec")
    target_extension = base / "custom_nodes/ComfyUI-GGUF"
    shutil.copytree(
        extension, target_extension, ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc")
    )
    (target_extension / "loader.py").write_text(patched)
    upstream = base / "qwen_image_gguf_loader_upstream.py"
    upstream.write_bytes(original)
    target = base / "custom_nodes/factory_qwen_latent"
    target.mkdir(parents=True)
    (target / "__init__.py").write_bytes(Path(__file__).with_name("latent_node.py").read_bytes())
    metadata = base / "qwen_image_native_dependencies.json"
    metadata.write_text(
        json.dumps(
            {
                "repository": "city96/ComfyUI-GGUF",
                "revision": GGUF_REVISION,
                "loader_upstream_sha256": GGUF_LOADER_SHA256,
                "loader_patched_sha256": hashlib.sha256(
                    (target_extension / "loader.py").read_bytes()
                ).hexdigest(),
            },
            sort_keys=True,
        )
        + "\n"
    )
    for path in [
        metadata,
        upstream,
        *[p for p in (base / "custom_nodes").rglob("*") if p.is_file()],
    ]:
        backend.adapter_assets[str(path.relative_to(backend.directory))] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
        stat = path.stat()
        backend._files[str(path)] = (stat.st_ino, stat.st_size, stat.st_mtime_ns)
