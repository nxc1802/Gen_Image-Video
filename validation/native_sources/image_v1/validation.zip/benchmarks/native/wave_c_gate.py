"""Recompute native image semantics from real collected bytes; never grants READY."""

import hashlib
import json
from pathlib import Path
from benchmarks.native.wave_a import digest
from benchmarks.native.wave_a_gate import evaluate
from benchmarks.native.image_inputs import derive
from benchmarks.native.image_semantic import semantic
from factory.adapters.qwen_image.native_nodes import GGUF_REVISION, GGUF_LOADER_SHA256

ROOT = Path(__file__).resolve().parents[2]


def evaluate_images(root=ROOT):
    inputs = {}

    def validate_report(kind, setup, observed, verified_raw):
        pin = json.loads((root / "deployments/kaggle/runtime_wave_c.json").read_text())["comfyui"]
        assert setup["runtime_pins"]["comfyui"] == pin, "Native Comfy pin drift"
        assert all(
            observed["runtime_versions"][name] == pin[name]
            for name in ["torch", "torchvision", "torchaudio", "transformers", "gguf"]
        ), "Native image runtime drift"
        run = json.loads((root / "validation/native_image_run.json").read_text())
        folder = root / f"validation/native_image_v{run['response']['versionNumber']}"
        for name, spec in observed["input_assets"].items():
            raw = verified_raw(folder / "inputs" / name / "source.bin")
            assert (
                len(raw) == spec["size_bytes"] and hashlib.sha256(raw).hexdigest() == spec["sha256"]
            )
            if "recipe" in spec:
                assert raw == derive(spec["recipe"], inputs), "Technical image input recipe drift"
            inputs[name] = raw
        verification = observed.get("semantic_verifiers")
        if verification:
            pins = json.loads((root / "benchmarks/native/image_semantic_pins.json").read_text())
            assert verification["scope"] == pins["scope"] and verification["pins_sha256"] == digest(
                pins
            )
            assert verification["verified_files"] == {
                name: {**spec, "matched": True} for name, spec in pins["files"].items()
            }
            loaded = verification["loaded"]
            assert (
                loaded["devices"] == ["cpu"]
                and loaded["dtypes"] == ["torch.float32"]
                and loaded["parameter_count"] == 151277313
            )
        for model in observed["models"]:
            backend = model.get("runtime_after_inference")
            if not backend:
                continue
            assert backend["source_revision"] == pin["source_revision"] and backend["devices"] == [
                0
            ]
            assets = backend["adapter_assets"]
            for name, sha in assets.items():
                raw = verified_raw(folder / model["model"] / "adapter_assets" / name)
                assert hashlib.sha256(raw).hexdigest() == sha, (
                    "Private image Adapter source integrity failed"
                )
            name = next(n for n in assets if n.endswith("/qwen_image_native_dependencies.json"))
            metadata = json.loads(verified_raw(folder / model["model"] / "adapter_assets" / name))
            assert (
                metadata["revision"] == GGUF_REVISION
                and metadata["loader_upstream_sha256"] == GGUF_LOADER_SHA256
            )
            upstream_name = next(
                n for n in assets if n.endswith("/qwen_image_gguf_loader_upstream.py")
            )
            assert assets[upstream_name] == GGUF_LOADER_SHA256
            loader_name = next(n for n in assets if n.endswith("/ComfyUI-GGUF/loader.py"))
            assert assets[loader_name] == metadata["loader_patched_sha256"]

    report = evaluate(
        root,
        wave="c",
        models=("qwen-image-2.1", "qwen-image-2.1-turbo"),
        kinds=("image",),
        validator=lambda case, output: semantic(case, output, assets=inputs),
        report_validator=validate_report,
    )
    for dependency in ("a", "b"):
        gate = json.loads((root / f"validation/native_wave_{dependency}_gate.json").read_text())
        if gate["exit_gate"] != "PASS":
            report["exit_gate"] = "NOT_MET"
            report["findings"].append("Wave " + dependency.upper() + " dependency gate is not PASS")
    report["excluded"] = json.loads((root / "benchmarks/native/golden_wave_c.json").read_text())[
        "excluded"
    ]
    return report


def main():
    report = evaluate_images()
    (ROOT / "validation/native_wave_c_gate.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {
                "exit_gate": report["exit_gate"],
                "native_pass": sum(c["status"] == "PASS" for c in report["cases"]),
                "findings": report["findings"],
            }
        )
    )
    return 0 if report["exit_gate"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
