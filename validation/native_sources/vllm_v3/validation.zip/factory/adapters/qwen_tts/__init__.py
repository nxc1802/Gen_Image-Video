import base64
from factory.core.model_adapter import ModelAdapter, PreparedCall
from factory.core.media import data_bytes, check_parameters, artifact
from factory_contracts.errors import InvalidRequestError


class Adapter(ModelAdapter):
    capabilities=frozenset({"speech.tts","speech.voice_cloning"})
    supported_backends=frozenset({"vllm_omni"})

    def required_capabilities(self,request,capability): return {capability,"speech.tts"}

    def resolve_capability(self,request,operation):
        return "speech.voice_cloning" if request.inputs.get("reference_audio") else operation

    def validate_request(self,model,request,capability):
        check_parameters(model,request.inputs,{"text","reference_audio","reference_text","voice","speed","response_format"})
        if not isinstance(request.inputs.get("text"),str) or not request.inputs["text"].strip(): raise InvalidRequestError("TTS text is required.")
        if not request.inputs.get("reference_audio") or not request.inputs.get("reference_text"):
            raise InvalidRequestError("Selected Base checkpoint requires reference audio and its transcript; no preset/VoiceDesign fallback.")
        data_bytes(request.inputs["reference_audio"],"audio")
        if request.inputs.get("voice") not in (None,"default"): raise InvalidRequestError("Preset voices require a separately selected checkpoint.")
        if request.inputs.get("response_format","wav")!="wav": raise InvalidRequestError("This adapter currently validates WAV output only.")

    def prepare(self,context,request,capability):
        ref="data:audio/wav;base64,"+base64.b64encode(data_bytes(request.inputs["reference_audio"],"audio")).decode()
        payload={"model":context.binding.model,"input":request.inputs["text"],"task_type":"Base","ref_audio":ref,
                 "ref_text":request.inputs["reference_text"],"response_format":"wav","non_streaming_mode":True,"speed":request.inputs.get("speed",1.0)}
        return PreparedCall(capability,payload)

    def infer(self,context,prepared): return context.post_bytes("/v1/audio/speech",prepared.payload)

    def normalize_output(self,context,prepared,output): return {"model":context.binding.model,"artifacts":[artifact(output,"audio","audio/wav")]}
