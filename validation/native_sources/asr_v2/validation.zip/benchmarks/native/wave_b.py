"""Wave B exact native ASR probe; other Wave B capabilities remain unverified."""

import argparse
import asyncio
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import urllib.request
import wave
from importlib.metadata import version

from benchmarks.native.wave_a import digest, model_run
from factory.core.media import MediaRequest
from model_registry.deployment_validator import inspect_environment

ROOT = Path(__file__).resolve().parents[2]


def words(text):
    return re.findall(r"[a-z0-9]+", text.casefold())


def word_error_rate(reference, hypothesis):
    reference, hypothesis = words(reference), words(hypothesis)
    if not reference:
        raise ValueError("A semantic reference must contain words")
    previous = list(range(len(hypothesis) + 1))
    for index, expected in enumerate(reference, 1):
        current = [index]
        for j, actual in enumerate(hypothesis, 1):
            current.append(
                min(current[-1] + 1, previous[j] + 1, previous[j - 1] + (expected != actual))
            )
        previous = current
    return previous[-1] / len(reference)


def semantic(case, output):
    text = output.get("text", "")
    expected = case["expected"]
    wer = word_error_rate(expected["transcript"], text)
    normalized = " ".join(words(text))
    checks = {
        "transcript_matches_ground_truth": wer <= expected["max_word_error_rate"],
        "required_spoken_phrases": all(p in normalized for p in expected["required_phrases"]),
    }
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "metrics": {"word_error_rate": wer, "actual_transcript": text},
    }


def decode_asset(spec, directory):
    directory.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(spec["url"], timeout=120) as response:
        raw = response.read(spec["size_bytes"] + 1)
    if len(raw) != spec["size_bytes"] or hashlib.sha256(raw).hexdigest() != spec["sha256"]:
        raise ValueError("Pinned real-audio fixture integrity failed")
    source = directory / "source.flac"
    source.write_bytes(raw)
    pcm = subprocess.check_output(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-i",
            str(source),
            "-map",
            "0:a:0",
            "-acodec",
            "pcm_s16le",
            "-f",
            "s16le",
            "pipe:1",
        ],
        timeout=30,
    )
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as target:
        target.setnchannels(spec["channels"])
        target.setsampwidth(2)
        target.setframerate(spec["sample_rate"])
        target.writeframes(pcm)
    result = buffer.getvalue()
    if (
        len(result) != spec["decoded_wav_size_bytes"]
        or hashlib.sha256(result).hexdigest() != spec["decoded_wav_sha256"]
    ):
        raise ValueError("Decoded actual WAV differs from pinned native input")
    (directory / "input_identity.json").write_text(json.dumps(spec, indent=2) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--models", nargs="+", required=True)
    args = parser.parse_args()
    if args.models != ["qwen-asr"]:
        raise ValueError("Only the explicit ASR Wave B subset is implemented")
    suite = json.loads((ROOT / "benchmarks/native/golden_wave_b.json").read_text())
    asset = decode_asset(suite["assets"]["jfk"], args.output / "inputs")

    async def execute(context, adapter, case):
        request = MediaRequest(
            model=case["model"],
            capability=case["capability"],
            inputs={"audio": asset, **case["request"]},
        )
        capability = adapter.resolve_capability(request, case["capability"])
        required = adapter.required_capabilities(request, capability) | {capability}
        if any(
            not context.model.capabilities.get(cid) or cid not in adapter.capabilities
            for cid in required
        ):
            raise ValueError("Undeclared speech capability")
        adapter.validate_request(context.model, request, capability)
        prepared = await asyncio.to_thread(adapter.prepare, context, request, capability)
        raw = await asyncio.to_thread(adapter.infer, context, prepared)
        return await asyncio.to_thread(adapter.normalize_output, context, prepared, raw)

    report = {
        "classification": "REAL_NATIVE_VALIDATION_ATTEMPT",
        "hardware": inspect_environment().gpus,
        "cases_sha256": digest({"cases": suite["cases"], "assets": suite["assets"]}),
        "case_definitions": suite["cases"],
        "input_assets": suite["assets"],
        "runtime_versions": {
            name: version(name)
            for name in ["qwen-asr", "torch", "transformers", "huggingface-hub", "psutil"]
        },
        "models": [],
        "fallback": False,
        "production_ready": False,
        "full_factory_e2e_executed": False,
    }
    assert set(report["hardware"]) == {0, 1} and all(
        "t4" in v["name"].lower() for v in report["hardware"].values()
    )
    directory = args.output / "qwen-asr"
    directory.mkdir(exist_ok=True)
    result = asyncio.run(
        model_run(
            "qwen-asr", args.root, directory, suite["cases"], executor=execute, validator=semantic
        )
    )
    report["models"].append(result)
    report["status"] = result["status"]
    (args.output / "wave_b.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "native_scope": "ASR_ONLY_NOT_FULL_WAVE_B"}))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
